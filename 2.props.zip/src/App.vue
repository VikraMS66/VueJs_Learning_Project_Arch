<template>
  <HelloWorld name="Vikram"/>
  <SayName :name="name" />
  <hr/>
  <h5>Blog Post using dynamic props</h5>
  <DynamicProps />
  <hr/>
</template>

<script>
import DynamicProps from './components/DynamicProps.vue';
import HelloWorld from './components/HelloWorld.vue';
import SayName from './components/SayName.vue';


export default {
  name: 'App',
  components: {
    HelloWorld,
    SayName,
    DynamicProps, 
},
data() {
  return {
    name: 'Vikram',
  }
},
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
