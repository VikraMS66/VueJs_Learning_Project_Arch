<template>
  <div class="hello">
    <h1>Welcome to Vue: {{ name }}</h1>
    
  </div>
</template>

<script>

export default {
  name: 'HelloWorld',
  props: ['name'],
  created() {
    console.log(this.name);
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
