<template>
    <BlogPost :post="post" />
    <BlogPost :post="{title: 'Props in Vue', description: 'Static and dynamic props', likes: 200}" />

 </template>
 
 <script>
import BlogPost from './BlogPost.vue';
 export default {
   name: 'DynamicProps', 

   components: {
    BlogPost,
    },

   data() {
    return {
        post: {
            title: "Welcome to Vue",
            description: "2nd most used javascript framework",
            likes: 240,
        },
    }
   } 
 }
 </script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
 <style scoped>
 </style>