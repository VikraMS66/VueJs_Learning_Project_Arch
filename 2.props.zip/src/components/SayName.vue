<template>
     <h1>Hello: {{ name }}</h1>  
  </template>
  
  <script>
  
  export default {
    name: 'SayName',
    props: {
        name: String,
    },
    created() {
        console.log(this.name);
    }
    
  }
  </script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only -->
  <style scoped>
  </style>