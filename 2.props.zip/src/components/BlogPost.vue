<template>
    <div>
        <h1>Title: {{ post.title }}</h1>
        <p>Description: {{post.description}}</p>
        <h4>Likes: {{post.likes}}</h4>
    </div>
</template>
 
<script>

export default {
    name: 'BlogPost',
    props: {
        post: {
            title: String,
            description: String,
            likes: Number,
        }
    },

}
</script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>