<template>
    <h1>View All Players</h1>
    <hr/>
    <div>
        <ul>
            <li v-for="plr in players" :key="plr.id">
              {{plr.id}} - {{plr.name}} - {{plr.category}} - {{plr.country}}
            </li>
        </ul>
    </div>
 </template>
 
 <script>
 export default {
    data() {
        return {
            players: [
                {id: 1, name: 'Rohit', country: 'India', category: 'Batter'},
                {id: 2, name: 'Virat', country: 'India', category: 'Keeper'},
                {id: 3, name: 'Dhoni', country: 'India', category: 'Batter'},
            ]
        }
    }
 }
 
 </script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
 <style scoped>
 
 </style>
 