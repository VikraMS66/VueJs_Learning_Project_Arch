<template>
    <h1>Update Player</h1>
    <hr />
    <div>
        <h4>{{ player.id }} - {{ player.name }} - {{ player.category }} - {{ player.country }}</h4>
    </div>
</template>
 
<script>
export default {
    data() {
        return {

            player: { id: 1, name: 'Rohit', country: 'India', category: 'Batter' },
        }
    }
}

</script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
 