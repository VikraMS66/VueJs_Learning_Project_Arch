<template>
  <a href="#/">Players</a> |
  <a href="#/player">Player</a> |
  <a href="#/update">Update-Player</a> |
  <a href="#/delete">Delete-Player</a>
  <component :is="currentView" />
</template>

<script>
import DeletePlayer from './components/DeletePlayer.vue'
import UpdatePlayer from './components/UpdatePlayer.vue'
import ViewPlayer from './components/ViewPlayer.vue'
import ViewPlayers from './components/ViewPlayers.vue'
import NotFound from './components/NotFound.vue'

const routes = {
  '/': ViewPlayers,
  '/player': ViewPlayer,
  '/update': UpdatePlayer,
  '/delete': DeletePlayer,
}

export default {
  data() {
    return {
      currentPath: window.location.hash,
    }
  },
  computed: {
    currentView() {
      return routes[this.currentPath.slice(1) || '/'] || NotFound
    }
  },
  mounted() {
    window.addEventListener('hashchange', () => {
      this.currentPath = window.location.hash
    })
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>


