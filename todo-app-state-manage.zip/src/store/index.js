import { defineStore } from "pinia";

export const useTodoListStore = defineStore("todoList", {
  state: () => ({ todoList: [], nextId: 0 }),
  getters: {},
  actions: {
    addTodo(item) {
      this.todoList.push({ item, id: this.nextId++, completed: false });
      console.table(this.todoList);
    },

    deleteTodo(itemID) {
      this.todoList = this.todoList.filter((object) => {
        return object.id !== itemID;
      });
      console.table(this.todoList);
    },

    toggleCompleted(idToFind) {
      const todo = this.todoList.find((obj) => obj.id === idToFind);
      if (todo) {
        todo.completed = !todo.completed;
      }
      console.table(this.todoList);
    },
  },
});
