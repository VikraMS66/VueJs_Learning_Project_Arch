<template>
  <h1 style="margin-left: 70px">Todo App</h1>
  <hr />
  <div>
    <TodoForm />
  </div>
  <div>
    <TodoList />
  </div>
</template>

<script>
import TodoForm from "./TodoForm.vue";
import TodoList from "./TodoList.vue";

export default {
  components: {
    TodoForm,
    TodoList,
  },
  setup() {
    return {};
  },
};
</script>

<style scoped></style>
