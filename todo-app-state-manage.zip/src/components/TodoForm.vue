<template>
  <form @submit.prevent="addItemAndClear(todo)" style="margin-left: 70px">
    <input v-model="todo" placeholder="Enter task name" type="text" /><button>
      Add
    </button>
  </form>
</template>

<script>
import { ref } from "vue";
import { useTodoListStore } from "@/store/index";
export default {
  setup() {
    const todo = ref("");

    // use Pinia store:
    const store = useTodoListStore();

    function addItemAndClear(item) {
      if (item.length === 0) {
        return;
      }

      store.addTodo(item);
      todo.value = "";
    }

    return { todo, store, addItemAndClear };
  },
};
</script>

<style scoped></style>
