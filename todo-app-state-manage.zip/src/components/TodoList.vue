<template>
  <ol>
    <div v-for="todo in todoList.reverse()" :key="todo.id" style="margin: 10px">
      <li>
        <input
          type="checkbox"
          @change="toggleCompleted(todo.id)"
          name="{{todo.item}}"
          value="{{todo.item}}"
          id="{{todo.id}}"
          :checked="todo.completed"
        />
        <label for="{{todo.id}}">{{ todo.item }}</label>
        <input
          type="button"
          @click="deleteTodo(todo.id)"
          value="Delete"
          style="margin: 10px"
        />
      </li>
    </div>
  </ol>
</template>

<script>
import { useTodoListStore } from "@/store/index";
import { storeToRefs } from "pinia";
export default {
  setup() {
    const store = useTodoListStore();

    // storeToRefs lets todoList keep reactivity:
    const { todoList } = storeToRefs(store);

    const { toggleCompleted, deleteTodo } = store;

    return { todoList, toggleCompleted, deleteTodo };
  },
};
</script>

<style scoped></style>
