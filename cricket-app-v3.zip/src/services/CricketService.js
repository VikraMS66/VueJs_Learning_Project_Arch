import axios from "axios";

const baseUrl = `http://localhost:7070/cricket/api/players`;

export const getAllPlayers = () => {
  return axios.get(`${baseUrl}`);
};

export const getPlayer = (id) => {
  return axios.get(`${baseUrl}/${id}`);
};

export const createPlayer = (body) => {
  return axios.post(`${baseUrl}`, body);
};

export const updatePlayer = (id, body) => {
  return axios.put(`${baseUrl}/${id}`, body);
};

export const deletePlayer = (id) => {
  return axios.delete(`${baseUrl}/${id}`);
};
