import { defineStore } from "pinia";

export const usePlayerStore = defineStore("player", {
  state: () => ({ player: {} }),
  getters: {},
  actions: {
    setPlayer(plr) {
      this.player = plr;
    },
  },
});
