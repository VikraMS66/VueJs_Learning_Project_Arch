<template>
  <form @submit.prevent class="mx-5 my-3">
    <v-text-field
      v-model="player.name"
      class="input-size"
      label="Name"
      placeholder="Player Name"
      required
    >
    </v-text-field>
    <v-text-field
      v-model="player.category"
      class="input-size"
      label="Category"
      placeholder="Player Name"
      required
    ></v-text-field>
    <v-text-field
      v-model="player.country"
      class="input-size"
      label="Country"
      placeholder="Player Name"
      required
    ></v-text-field>
    <v-text-field
      v-model="player.image"
      class="input-size"
      label="Image URL"
      placeholder="Player Name"
      required
    ></v-text-field>
    <div class="input-size">
      <v-btn class="mx-5" color="blue" type="submit" @click="addPlayer">
        submit
      </v-btn>
      <v-btn color="grey" class="mx-5" @click="clear"> clear </v-btn>
    </div>
  </form>
</template>

<script>
import { createPlayer } from "@/services/CricketService";
import router from "../router";

export default {
  name: "NewPlayer",

  data: () => ({
    player: {
      name: "",
      country: "",
      category: "",
      image: "",
    },
  }),

  methods: {
    clear() {
      this.player.name = "";
      this.player.country = "";
      this.player.category = "";
      this.player.image = "";
    },
    addPlayer() {
      console.table(this.player);
      createPlayer(this.player)
        .then((res) => {
          console.table(res.data);
          alert("Player added!");
          router.push({ path: "/players" });
        })
        .catch((err) => console.error(err));
    },
  },
};
</script>

<style scoped>
.input-size {
  width: 25%;
  margin-left: 500px;
}
</style>
