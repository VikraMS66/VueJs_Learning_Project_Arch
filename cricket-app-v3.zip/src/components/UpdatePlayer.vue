<template>
  <div class="my-2">
    <form @submit.prevent>
      <v-card class="mx-auto my-2" max-width="250">
        <v-img
          class="white--text align-center"
          height="200"
          width="250"
          :src="player.image"
        ></v-img>
      </v-card>
      <v-text-field
        v-model="player.name"
        class="input-size"
        label="Name"
        placeholder="Player Name"
        required
      >
      </v-text-field>
      <v-text-field
        v-model="player.category"
        class="input-size"
        label="Category"
        placeholder="Player Name"
        required
      ></v-text-field>
      <v-text-field
        v-model="player.country"
        class="input-size"
        label="Country"
        placeholder="Player Name"
        required
      ></v-text-field>
      <v-text-field
        v-model="player.image"
        class="input-size"
        label="Image URL"
        placeholder="Player Name"
        required
      ></v-text-field>

      <div class="input-size">
        <v-btn class="mx-5" color="blue" type="submit" @click="updatePlayer">
          submit
        </v-btn>
        <v-btn class="mx-5 px-3" color="black" @click="goBack"> Back </v-btn>
      </div>
    </form>
  </div>
</template>

<script>
import { updatePlayer } from "@/services/CricketService";
import router from "../router";
import { usePlayerStore } from "@/store/index";
import { storeToRefs } from "pinia";

export default {
  name: "UpdatePlayer",

  data: () => ({
    player: {
      id: Number,
      name: String,
      country: String,
      category: String,
      image: String,
    },
  }),

  created() {
    const store = usePlayerStore();
    const { player } = storeToRefs(store);
    // console.table(player);
    this.player = player;
  },

  methods: {
    updatePlayer() {
      console.table(this.player);
      updatePlayer(+this.player.id, this.player)
        .then((res) => {
          console.table(res.data);
          alert("Player updated!");
          router.push({ path: "/players" });
        })
        .catch((err) => console.error(err));
    },
    goBack() {
      router.push({ path: "/view", query: { id: this.player.id } });
    },
  },
};
</script>
<style scoped>
.input-size {
  width: 25%;
  margin-left: 500px;
}
</style>
