<template>
  <div class="home text-center">
    <div class="about mx-2">
      <div class="entry-content">
        <h4>Cricket: The game and the field</h4>
        <p>
          Cricket is a bat and ball game played between two teams of 11 players
          on a large round field.
        </p>
        <p>
          In the centre of the field is a rectangular pitch (20m long) where the
          bowling and batting action takes place.
        </p>
        <div
          id="gallery-1"
          class="gallery galleryid-3069 gallery-columns-1 gallery-size-large"
        >
          <dl class="gallery-item">
            <dt class="gallery-icon landscape">
              <a
                href="https://englishenglish.biz/wp-content/uploads/2015/07/MCG1.jpg"
                ><img
                  width="1024"
                  height="576"
                  src="https://englishenglish.biz/wp-content/uploads/2015/07/MCG1-1024x576.jpg"
                  class="attachment-large size-large"
                  alt=""
                  loading="lazy"
                  aria-describedby="gallery-1-3074"
                  srcset="
                    https://englishenglish.biz/wp-content/uploads/2015/07/MCG1.jpg         1024w,
                    https://englishenglish.biz/wp-content/uploads/2015/07/MCG1-300x169.jpg  300w,
                    https://englishenglish.biz/wp-content/uploads/2015/07/MCG1-768x432.jpg  768w
                  "
                  sizes="(max-width: 1024px) 100vw, 1024px"
              /></a>
            </dt>
            <dd class="wp-caption-text gallery-caption" id="gallery-1-3074">
              Melbourne Cricket Ground in Australia
            </dd>
          </dl>
          <br style="clear: both" />
        </div>

        <p>
          Like baseball, one team ‘bats’ while the other team ‘fields’.<br />
          However, in cricket the batting team bat in pairs, and they continue
          batting until 10 of the 11 team members are ‘out’.<br />
          The fielding team must continue fielding until 10 of the batting team
          are ‘out’ (i.e. there is only one batter left &#8211; no pair).
        </p>
        <p>
          A game of cricket is divided into ‘Overs’ and ‘Innings’. One ‘over’ is
          made up of 6 balls. After 6 balls have been bowled, the bowler must
          change. Anyone on the fielding team can bowl, but most teams usually
          have 4 or 5 specialist bowlers and 5 or 6 specialist batsmen.
        </p>
      </div>
    </div>
  </div>
  <hr />
  <FooterView />
</template>

<script>
// @ is an alias to /src

export default {
  name: "HomeView",
};
</script>
