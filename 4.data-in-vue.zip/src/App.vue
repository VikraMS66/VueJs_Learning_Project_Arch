<template>
  <hr/>
  <DataTwoWayBinding />
  <hr/>
  <h1>{{name}}</h1>
  <h1>{{numbers.length}}</h1>
  <h1>{{numbers[1]}}</h1>
  <h1>{{numbers}}</h1>
  <h1>{{user.username}}</h1>
  <h1>{{user.age}}</h1>
  <h1>{{JSON.stringify(user)}}</h1>
  
</template>

<script>
import DataTwoWayBinding from './components/DataTwoWayBinding.vue';
export default {
  name: 'App',

  components: {
    DataTwoWayBinding,
  },

  data() {
    return {
      name: 'Vikram',
      numbers: [1,2,3,4,5],
      
      user: {
        username: 'Vikas',
        email: 'vikas@yahoo.com',
        age: 25,
        address: {
          zipCode: 123456,
          city: 'Hyderabad'
        }
      }
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
