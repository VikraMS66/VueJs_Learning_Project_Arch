<template>
    <h2>Message is: {{ msg }}</h2>
    <input type="text" placeholder="Enter your message" v-model="msg" />
    <hr />
    <input type="checkbox" id="checkbox" v-model="checked" />
    <label for="checkbox">{{ checked }}</label>
    <hr />
    <h3 v-if="checkedNames.length === 3">Top 3 players selected</h3>
    <div>Checked names: {{ checkedNames }}</div>

    <input type="checkbox" id="rohit" value="Rohit" v-model="checkedNames">
    <label for="rohit">Rohit</label>

    <input type="checkbox" id="virat" value="Virat" v-model="checkedNames">
    <label for="virat">Virat</label>

    <input type="checkbox" id="dhoni" value="Dhoni" v-model="checkedNames">
    <label for="dhoni">Dhoni</label>

    <hr />

    <div>Picked: {{ picked }}</div>

    <input type="radio" id="one" value="One" v-model="picked" />
    <label for="one">One</label>

    <input type="radio" id="two" value="Two" v-model="picked" />
    <label for="two">Two</label>

    <hr />

    <span>Multiline message is:</span>
    <p style="white-space: pre-line;">{{ message }}</p>
    <textarea v-model="message" placeholder="add multiple lines"></textarea>

    <hr />

    <div>Selected: {{ selected }}</div>

    <select v-model="selected">
        <option disabled value="">Please select one</option>
        <option>Rohit</option>
        <option>Dhoni</option>
        <option>Rohit</option>
    </select>

    <hr />

    <h3 v-if="players.length === 3">Top 3 players selected</h3>
    <div>Selected: {{ players }}</div>

    <select v-model="players" multiple>
        <option>Rohit</option>
        <option>Dhoni</option>
        <option>Virat</option>
    </select>

</template>
  
<script>
export default {
    name: 'DataTwoWayBinding',

    data() {
        return {
            msg: '',
            message: '',
            selected: '',
            players: [],
            checked: false,
            checkedNames: [],
            picked: '',
        }
    }
}
</script>
  
<style scoped>

</style>
  