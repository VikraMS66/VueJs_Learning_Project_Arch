<template>
  <div class="about mx-2">
    <div class="entry-content">
      <h4>Cricket: The game and the field</h4>
      <p>
        Cricket is a bat and ball game played between two teams of 11 players on
        a large round field.
      </p>
      <p>
        In the centre of the field is a rectangular pitch (20m long) where the
        bowling and batting action takes place.
      </p>
      <div
        id="gallery-1"
        class="gallery galleryid-3069 gallery-columns-1 gallery-size-large"
      >
        <dl class="gallery-item">
          <dt class="gallery-icon landscape">
            <a
              href="https://englishenglish.biz/wp-content/uploads/2015/07/MCG1.jpg"
              ><img
                width="1024"
                height="576"
                src="https://englishenglish.biz/wp-content/uploads/2015/07/MCG1-1024x576.jpg"
                class="attachment-large size-large"
                alt=""
                loading="lazy"
                aria-describedby="gallery-1-3074"
                srcset="
                  https://englishenglish.biz/wp-content/uploads/2015/07/MCG1.jpg         1024w,
                  https://englishenglish.biz/wp-content/uploads/2015/07/MCG1-300x169.jpg  300w,
                  https://englishenglish.biz/wp-content/uploads/2015/07/MCG1-768x432.jpg  768w
                "
                sizes="(max-width: 1024px) 100vw, 1024px"
            /></a>
          </dt>
          <dd class="wp-caption-text gallery-caption" id="gallery-1-3074">
            Melbourne Cricket Ground in Australia
          </dd>
        </dl>
        <br style="clear: both" />
      </div>

      <p>
        Like baseball, one team ‘bats’ while the other team ‘fields’.<br />
        However, in cricket the batting team bat in pairs, and they continue
        batting until 10 of the 11 team members are ‘out’.<br />
        The fielding team must continue fielding until 10 of the batting team
        are ‘out’ (i.e. there is only one batter left &#8211; no pair).
      </p>
      <p>
        A game of cricket is divided into ‘Overs’ and ‘Innings’. One ‘over’ is
        made up of 6 balls. After 6 balls have been bowled, the bowler must
        change. Anyone on the fielding team can bowl, but most teams usually
        have 4 or 5 specialist bowlers and 5 or 6 specialist batsmen.
      </p>
      <h4></h4>
      <h4>Scoring runs</h4>
      <p>
        The batting team must score as many ‘runs’ as possible, by hitting the
        ball and running to the other end of the pitch. If the batsman can reach
        the other end of the pitch successfully, he scores 1 ‘run’. If he can
        reach the other end of the pitch and return, he scores 2 runs etc.<br />
        If he hits the ball to the edge of the field, he scores 4 runs. If he
        can hit the ball to the edge of the field without bouncing, he scores 6
        runs.<br />
        The batsman can continue to bat until he is ‘out’ &#8211; and then he
        will be replaced by his next teammate.<br />
        Sometimes the first batsman is never out, and he scores 100 or 200+ runs
        in the game.
      </p>
      <div
        id="gallery-2"
        class="gallery galleryid-3069 gallery-columns-1 gallery-size-large"
      >
        <dl class="gallery-item">
          <dt class="gallery-icon landscape">
            <a
              href="https://englishenglish.biz/wp-content/uploads/2015/07/batsmenrunning1.jpg"
              ><img
                width="960"
                height="540"
                src="https://englishenglish.biz/wp-content/uploads/2015/07/batsmenrunning1.jpg"
                class="attachment-large size-large"
                alt=""
                loading="lazy"
                aria-describedby="gallery-2-3073"
                srcset="
                  https://englishenglish.biz/wp-content/uploads/2015/07/batsmenrunning1.jpg         960w,
                  https://englishenglish.biz/wp-content/uploads/2015/07/batsmenrunning1-300x169.jpg 300w,
                  https://englishenglish.biz/wp-content/uploads/2015/07/batsmenrunning1-768x432.jpg 768w
                "
                sizes="(max-width: 960px) 100vw, 960px"
            /></a>
          </dt>
          <dd class="wp-caption-text gallery-caption" id="gallery-2-3073">
            2 batsmen running after hitting the ball
          </dd>
        </dl>
        <br style="clear: both" />
      </div>

      <p>&nbsp;</p>
      <h4>Bowling</h4>
      <p>
        There are many different kinds of bowlers; some bowl very fast, and some
        bowl slower but spin the ball. One very important rule for all bowlers
        is that the ball must bounce once before reaching the batsman.<br />
        This is obviously very different to baseball, where the ball doesn’t
        bounce between pitcher and hitter.
      </p>
      <p>&nbsp;</p>
      <div
        id="gallery-3"
        class="gallery galleryid-3069 gallery-columns-1 gallery-size-large"
      >
        <dl class="gallery-item">
          <dt class="gallery-icon landscape">
            <a
              href="https://englishenglish.biz/wp-content/uploads/2015/07/fastbowler1.jpg"
              ><img
                width="640"
                height="194"
                src="https://englishenglish.biz/wp-content/uploads/2015/07/fastbowler1.jpg"
                class="attachment-large size-large"
                alt=""
                loading="lazy"
                aria-describedby="gallery-3-3079"
                srcset="
                  https://englishenglish.biz/wp-content/uploads/2015/07/fastbowler1.jpg        640w,
                  https://englishenglish.biz/wp-content/uploads/2015/07/fastbowler1-300x91.jpg 300w
                "
                sizes="(max-width: 640px) 100vw, 640px"
            /></a>
          </dt>
          <dd class="wp-caption-text gallery-caption" id="gallery-3-3079">
            A fast bowler&#8217;s bowling action
          </dd>
        </dl>
        <br style="clear: both" />
      </div>

      <p>
        Cricket is a very tactical game. The fielding team captain will change
        the positions of his fielders depending on the type of bowler or the
        type of batsman.
      </p>
      <h4></h4>
      <h4></h4>
      <h4>How to be &#8216;out&#8217;</h4>
      <p>The batsmen can be out in many different ways. For example:</p>
      <p>
        1) <span style="color: #ff0000"><strong>Caught</strong></span
        >: He hits the ball and a fielder catches it.<br />
        2) <strong><span style="color: #ff0000">Bowled</span></strong
        >: The bowler bowls the ball and hits the batsman’s ‘stumps’.<br />
        3) <strong><span style="color: #ff0000">LBW</span></strong> (Leg before
        wicket): The bowler bowls the ball and hits the batsman’s legs &#8211;
        which block the ball hitting the ’stumps’.<br />
        4) <span style="color: #ff0000"><strong>Run out</strong></span
        >: The batsmen try to run, but the fielding team throw the ball and hit
        the stumps before the batsman is safe.<br />
        5) <span style="color: #ff0000"><strong>Hit wicket</strong></span
        >: The batsman hits his own stumps with his body, equipment, or
        clothing.
      </p>

      <div
        id="gallery-4"
        class="gallery galleryid-3069 gallery-columns-2 gallery-size-large"
      >
        <dl class="gallery-item">
          <dt class="gallery-icon landscape">
            <a
              href="https://englishenglish.biz/wp-content/uploads/2015/07/bowled1.jpg"
              ><img
                width="636"
                height="450"
                src="https://englishenglish.biz/wp-content/uploads/2015/07/bowled1.jpg"
                class="attachment-large size-large"
                alt=""
                loading="lazy"
                aria-describedby="gallery-4-3082"
                srcset="
                  https://englishenglish.biz/wp-content/uploads/2015/07/bowled1.jpg         636w,
                  https://englishenglish.biz/wp-content/uploads/2015/07/bowled1-300x212.jpg 300w
                "
                sizes="(max-width: 636px) 100vw, 636px"
            /></a>
          </dt>
          <dd class="wp-caption-text gallery-caption" id="gallery-4-3082">
            Bowled!
          </dd>
        </dl>
        <dl class="gallery-item">
          <dt class="gallery-icon landscape">
            <a
              href="https://englishenglish.biz/wp-content/uploads/2015/07/catch1.jpg"
              ><img
                width="766"
                height="511"
                src="https://englishenglish.biz/wp-content/uploads/2015/07/catch1.jpg"
                class="attachment-large size-large"
                alt=""
                loading="lazy"
                aria-describedby="gallery-4-3083"
                srcset="
                  https://englishenglish.biz/wp-content/uploads/2015/07/catch1.jpg         766w,
                  https://englishenglish.biz/wp-content/uploads/2015/07/catch1-300x200.jpg 300w
                "
                sizes="(max-width: 766px) 100vw, 766px"
            /></a>
          </dt>
          <dd class="wp-caption-text gallery-caption" id="gallery-4-3083">
            Caught!
          </dd>
        </dl>
        <br style="clear: both" />
      </div>

      <p>&nbsp;</p>
      <h4>Types of cricket</h4>
      <p>
        Some games of cricket have 1 inning per team, and the team who scores
        the most runs is the winner.<br />
        Some forms of cricket have 2 innings per team, and the winning team is
        the team that scores the most runs in total.
      </p>
      <p>
        There are 3 types of cricket game.<br />
        The shortest and fastest game is called &#8216;Twenty 20&#8217;, and
        lasts 20 overs per team. A full game usually takes about 2.5 hours.<br />
        The medium length game is called a ‘One-day game’, and lasts for 50
        overs per team.<br />
        The longest length game is called a ‘Test Match’, and lasts for a
        maximum of 5 days. (2 innings per team).
      </p>
      <p>
        A ‘Test Match’ usually starts at 11:00am and finishes at 18:00pm, with a
        40 minute lunch break at 13:00, and 20 minute tea break at 15:40. 90
        overs are expected to be bowled during the day’s play.
      </p>
      <p>&nbsp;</p>
      <h4>Some interesting facts about cricket</h4>
      <p>
        Cricket is played by more than 120 million players in many countries
        which makes it the world’s second most popular sport.
      </p>
      <p>It was first played in England in the 16th century.</p>
      <p>
        As the British Empire expanded, cricket was introduced to more
        countries.
      </p>
      <p>By the mid 1850s, international games were being played.</p>
      <p>
        Cricket is most popular in England, Australia, India, South Africa, the
        West Indies, New Zealand, Pakistan, and Sri Lanka.<br />
        Recently countries such as Bangladesh, Zimbabwe, Kenya, Ireland,
        Afghanistan, Netherlands, and Canada have become more successful as the
        sport becomes more popular.
      </p>
      <p>&nbsp;</p>
    </div>
  </div>
</template>

<style scoped>
#gallery-4 {
  margin: auto;
}

#gallery-4 .gallery-item {
  float: left;
  margin-top: 10px;
  text-align: center;
  width: 50%;
}

#gallery-4 img {
  border: 2px solid #cfcfcf;
}

#gallery-4 .gallery-caption {
  margin-left: 0;
}

#gallery-3 {
  margin: auto;
}

#gallery-3 .gallery-item {
  float: left;
  margin-top: 10px;
  text-align: center;
  width: 100%;
}

#gallery-3 img {
  border: 2px solid #cfcfcf;
}

#gallery-3 .gallery-caption {
  margin-left: 0;
}

#gallery-2 {
  margin: auto;
}

#gallery-2 .gallery-item {
  float: left;
  margin-top: 10px;
  text-align: center;
  width: 100%;
}

#gallery-2 img {
  border: 2px solid #cfcfcf;
}

#gallery-2 .gallery-caption {
  margin-left: 0;
}

#gallery-1 {
  margin: auto;
}

#gallery-1 .gallery-item {
  float: left;
  margin-top: 10px;
  text-align: center;
  width: 100%;
}

#gallery-1 img {
  border: 2px solid #cfcfcf;
}

#gallery-1 .gallery-caption {
  margin-left: 0;
}
</style>
