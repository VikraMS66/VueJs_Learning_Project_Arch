<template>
  <div class="my-2">
    <v-card class="mx-auto" max-width="400">
      <v-img class="white--text align-end" height="200px" :src="player.image">
      </v-img>
      <v-card-title class="text-center">{{ player.name }}</v-card-title>
      <v-card-subtitle class="pb-0">
        {{ player.category }}
      </v-card-subtitle>

      <v-card-text class="text--primary">
        <div>{{ player.country }}</div>
      </v-card-text>

      <v-card-actions>
        <v-btn color="orange" text @click="getUpdate"> Update </v-btn>

        <v-btn color="red" text @click="deletePlayer"> Delete </v-btn>
      </v-card-actions>
    </v-card>
  </div>
</template>

<script>
import { deletePlayer, getPlayer } from "@/services/CricketService";
import router from "../router";

export default {
  name: "ViewPlayer",

  data: () => ({
    player: {
      id: Number,
      name: String,
      country: String,
      category: String,
      image: String,
    },
  }),

  mounted() {
    // console.log(this.$route.query.id);
    this.player.id = this.$route.query.id;
    getPlayer(this.player.id)
      .then((res) => (this.player = res.data))
      .catch((err) => console.error(err));
  },

  methods: {
    getUpdate() {
      router.push({ path: "/update", query: { id: this.player.id } });
    },

    deletePlayer() {
      if (confirm("Are you sure you want to delete?")) {
        deletePlayer(this.player.id)
          .then((res) => {
            console.table(res.data);
            router.push({ path: "/players", query: {} });
          })
          .catch((err) => console.error(err));
      }
    },
  },
};
</script>
