<template>
  <div style="display: block">
    <div v-for="plr in players" :key="plr.id" class="card-player mx-2 my-2">
      <v-card class="mx-auto" max-width="344" elevation="3" outlined shaped>
        <v-list-item three-line>
          <v-list-item-content>
            <v-list-img class="player-image ml-4">
              <v-img :src="plr.image"></v-img>
            </v-list-img>
            <v-list-item-media class="text-p mb-1">
              {{ plr.name }}
            </v-list-item-media>
            <v-list-item-subtitle>{{ plr.country }}</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>

        <v-card-actions>
          <v-btn
            color="secondary"
            outlined
            rounded
            text
            @click="getPlayer(plr.id)"
          >
            More Details
          </v-btn>
        </v-card-actions>
      </v-card>
    </div>
  </div>
</template>

<script>
import { getAllPlayers } from "@/services/CricketService";
import router from "../router";

export default {
  name: "ViewPlayers",

  data: () => ({
    players: [],
  }),

  created() {
    getAllPlayers()
      .then((res) => {
        this.players = res.data;
        this.players = this.players.sort((p1, p2) => p1.id - p2.id);
      })
      .catch((err) => {
        console.error(err);
      });
  },

  methods: {
    getPlayer(id) {
      router.push({ path: "/view", query: { id: id } });
    },
  },
};
</script>
<style scoped>
.card-player {
  float: left;
  height: 19rem;
  width: 20rem;
}

.player-image {
  width: 15rem;
  height: 11rem;
  align-items: center;
}
</style>
