<template>
  <nav class="mx-2">
    <h1 style="display: inline" class="mx-5">Cricket App</h1>
    <div style="display: inline" class="text-center">
      <router-link to="/">Home</router-link> |
      <router-link to="/players">Players</router-link> |
      <router-link to="/new">Add Player</router-link> |
      <router-link to="/about">About</router-link>
    </div>
  </nav>
  <hr />
  <div style="display: block">
    <router-view />
  </div>
  <!-- <div style="display: block">
    <FooterView />
  </div> -->
</template>
<script>
// import FooterView from "@/views/FooterView.vue";
export default {
  components: {
    // FooterView,
  },
};
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: start;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
