
<template>
  <h1>Directives</h1>
  <hr/>
  <a href="#/">Text</a> |
  <a href="#/html">html</a> |
  <a href="#/show">show</a> |
  <a href="#/if">if</a> |
  <a href="#/else">else</a> |
  <a href="#/elseIf">elseIf</a> |
  <a href="#/for">for</a> |
  <component :is="currentView" />
</template>

<script>
import TextDirective from '@/components/TextDirective.vue';
import HtmlDirective from '@/components/HtmlDirective.vue';
import IfDirective from '@/components/IfDirective.vue';
import ElseDirective from '@/components/ElseDirective.vue';
import ElseIfDirective from '@/components/ElseIfDirective.vue';
import ForDirective from '@/components/ForDirective.vue';
import ShowDirecitve from '@/components/ShowDirecitve.vue';
import NotFound from '@/components/NotFound.vue';

const routes = {
  '/': TextDirective,
  '/if': IfDirective,
  '/else': ElseDirective,
  '/elseIf': ElseIfDirective,
  '/for': ForDirective,
  '/html': HtmlDirective,
  '/show': ShowDirecitve,
}

export default {
  data() {
    return {
      currentPath: window.location.hash,
    }
  },
  computed: {
    currentView() {
      return routes[this.currentPath.slice(1) || '/'] || NotFound
    }
  },
  mounted() {
    window.addEventListener('hashchange', () => {
      this.currentPath = window.location.hash
    })
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>


