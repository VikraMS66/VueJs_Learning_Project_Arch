<template>
    <h1>v-for Directive</h1>
    <hr />
    <ol>
        <li v-for="(item, key) in items" :key="key">
            {{ item }}
        </li>
    </ol>
    <hr />
    <ul>
        <li v-for="(val, key) in messages" :key="key">
            {{ val.message }}
        </li>

    </ul>
    <hr />
    <ul>
        <li v-for="({ message }, key) in messages" :key="key">
            {{ message }}
        </li>
    </ul>
    <hr />
    <ol>
        <li v-for="(value, key) in myObject" :key="key">
          {{key}}: {{ value }}
        </li>
    </ol>
</template>
 
<script>
export default {
    data() {
        return {
            items: ['Apple', 'Orange', 'Mango'],
            messages: [{ message: 'Hello' }, { message: 'Good Morning' }, { message: 'Good Afternoon' }, { message: 'Good Evening' }, { message: 'Good Bye' }],
            myObject: {
                title: 'Directives in Vue',
                author: 'Vuejobs',
                publishedAt: '2022-11-09'
            }
        }
    }
}

</script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
 