<template>
    <h1>v-if Directive</h1>
    <hr />
    <div v-if="Math.random() > 0.5">
        Now you see me
    </div>
</template>
 
<script>

</script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
 