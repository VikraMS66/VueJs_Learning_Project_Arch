<template>
    <h1>v-text Directive</h1>
    <hr/>
    <span v-text="msg"></span>
    <!-- same as -->
    <br/>
    <span>{{ msg }}</span>
</template>
 
<script>
   export default {
    data() {
        return {
            msg: `v-text directive: Update the element's text content.`
        }
    }
   }
</script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
 