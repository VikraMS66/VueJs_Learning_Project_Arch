<template>
    <h1>v-else Directive</h1>
    <hr />
    <div v-if="Math.random() > 0.5">
        Now you see me
    </div>
    <div v-else>
        No! you can't see him.
    </div>
</template>
 
<script>

</script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
 