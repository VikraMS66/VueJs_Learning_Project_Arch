<template>
    <h1>v-show Directive</h1>
    <hr/>
    <h4 v-show="visibility">Toggle the element's visibility based on the truthy-ness of the expression value.</h4>
    <button @click="visibility = true">Show</button>
    <button @click="visibility = false">Hide</button>
 </template>
 
 <script>
 export default {
    data() {
        return {
            visibility: true,
        }
    }
 }
 </script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
 <style scoped>
 
 </style>
 