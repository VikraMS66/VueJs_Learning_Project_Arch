<template>
    <h1>v-else-if Directive</h1>
    <hr />
    <h4>Enter A or B or C</h4>
    <input type="text" v-model="type"/>
    <br/>
    <div v-if="type === 'A'">
        A
    </div>
    <div v-else-if="type === 'B'">
        B
    </div>
    <div v-else-if="type === 'C'">
        C
    </div>
    <div v-else>
        Not A/B/C
    </div>
</template>
 
<script>
export default {
    data() {
        return {
            type: ''
        }
    }
}

</script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
 