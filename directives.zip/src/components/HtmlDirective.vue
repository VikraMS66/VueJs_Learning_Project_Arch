<template>
    <h1>v-html Directive</h1>
    <hr />
    <div v-html="h1">

    </div>
</template>
 
<script>
export default {
    data() {
        return {
            h1: `<h1>Update the element's innerHTML.</h1>`,
        }
    }
}
</script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
 