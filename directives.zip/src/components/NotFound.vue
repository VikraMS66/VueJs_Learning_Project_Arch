<template>
    <h1>Page Not Found: 404</h1>
    <hr/>

 </template>
 
 <script>
 
 </script>
 
 <!-- Add "scoped" attribute to limit CSS to this component only -->
 <style scoped>
 
 </style>
 