<template>
    <h1>Counter: {{count}}</h1>
    <button @click="incement">Increment</button>
    <button @click="decerement">Decrelemt</button>
    <button @click="reset">Reset</button>
</template>
  
<script>

export default {
    name: 'MethodCounter',

    data() {
        return {
            count: 0,
        }
    },

    methods: {
        incement() {
            this.count++;
        },
        decerement() {
            this.count--;
        },
        reset() {
            this.count=0;
        }
    }
}
</script>
  
<style scoped>

</style>
  