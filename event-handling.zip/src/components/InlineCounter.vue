<template>
    <h1>Counter: {{count}}</h1>
    <button @click="count++">Increment</button>
    <button @click="count--">Decrelemt</button>
    <button @click="count=0">Reset</button>
</template>
  
<script>

export default {
    name: 'InlineCounter',

    data() {
        return {
            count: 0,
        }
    },
}
</script>
  
<style scoped>

</style>
  