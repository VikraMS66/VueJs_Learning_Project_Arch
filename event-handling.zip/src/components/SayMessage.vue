<template>
    <button @click="say('Hello')">Get In</button><br/>
    <button @click="say('GoodBye')">Leave</button>
</template>
  
<script>

export default {
    name: 'SayMessage',

    methods: {
        say(msg) {
            alert(msg);
        }
    }
}
</script>
  
<style scoped>

</style>
  