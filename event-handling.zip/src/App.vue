<template>
  <h3>Inline Event Handler</h3>
  <InlineCounter/>
  <hr/>
  <h3>Method Event Handler</h3>
  <MethodCounter/>
  <hr/>
  <SayMessage/>
</template>

<script>
import InlineCounter from '@/components/InlineCounter.vue'
import MethodCounter from '@/components/InlineCounter.vue'
import SayMessage from './components/SayMessage.vue';

export default {
  name: 'App',
  components: {
    InlineCounter,
    MethodCounter,
    SayMessage
}
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
