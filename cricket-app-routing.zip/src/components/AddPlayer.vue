<template>
  <h1>Add Player</h1>
  <hr />
</template>

<script>
export default {};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
