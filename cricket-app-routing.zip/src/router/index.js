import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";
import ViewPlayer from "../components/ViewPlayer.vue";
import ViewPlayers from "../components/ViewPlayers.vue";
import UpdatePlayer from "../components/UpdatePlayer.vue";
import DeletePlayer from "../components/DeletePlayer.vue";
import AddPlayer from "../components/AddPlayer.vue";

const routes = [
  {
    path: "/",
    name: "home",
    component: HomeView,
  },
  {
    path: "/players",
    name: "players",
    component: ViewPlayers,
  },
  {
    path: "/player",
    name: "player",
    component: ViewPlayer,
  },
  {
    path: "/update",
    name: "update",
    component: UpdatePlayer,
  },
  {
    path: "/delete",
    name: "delete",
    component: DeletePlayer,
  },
  {
    path: "/add",
    name: "add",
    component: AddPlayer,
  },

  {
    path: "/about",
    name: "about",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/AboutView.vue"),
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
