<template>
  <div class="home">
    <h1>Welcome to cricket app</h1>
  </div>
</template>

<script>
export default {
  name: "HomeView",
};
</script>
