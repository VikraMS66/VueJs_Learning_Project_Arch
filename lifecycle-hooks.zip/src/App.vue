<template>
  <h1>{{msg}}</h1>
  <button @click="updateMsg">Update</button>
</template>

<script>

export default {
  name: 'App',
  
  data() {
    return {
      msg: 'Hello'
    }
  },

  beforeCreate() {
    console.log('Creating');
  },

  created() {
    console.log('Created');
  },

  beforeMount() {
    console.log('Mounting');
  },

  mounted() {
    console.log('Mounted');
  },

  beforeUpdate(){
    console.log('Updating');
  },

  updated(){
    console.log('Updated');
  },

  beforeUnmount(){
    console.log('Umounting');
  },

  unmounted(){
    console.log('Unmounted');
  },
  
  methods: {
    updateMsg() {
      this.msg = 'Welcome to Vue';
    },

  }

}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
