package com.tm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tm.bean.Player;
import com.tm.repository.IPlayerRepo;

@Service
public class PlayerService implements IPlayerService {

	@Autowired
	private IPlayerRepo pRepo;

	@Override
	public List<Player> getAllPlayers() {
		// System.out.println(custRepo.findAll());
		return pRepo.findAll();
	}

	@Override
	public Player addPlayer(Player player) {
		return pRepo.save(player);
	}

	@Override
	public Player getPlayerById(long id) {
		return pRepo.findById(id).get();
	}

	@Override
	public Player updatePlayer(long id, Player playerDetails) {
		Player player = getPlayerById(id);
		player.setName(playerDetails.getName());
		player.setCategory(playerDetails.getCategory());
		player.setCountry(playerDetails.getCountry());
		player.setImage(playerDetails.getImage());
		return pRepo.save(player);
	}

	@Override
	public String deletePlayer(long id) {
		Player player = getPlayerById(id);
		pRepo.delete(player);
		return player.toString() + " player Deleted!";
	}

}
