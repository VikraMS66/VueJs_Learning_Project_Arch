package com.tm.service;

import java.util.List;

import com.tm.bean.Player;

public interface IPlayerService {

	List<Player> getAllPlayers();

	Player addPlayer(Player player);

	Player getPlayerById(long id);

	Player updatePlayer(long id, Player playerDetails);

	String deletePlayer(long id);
}
