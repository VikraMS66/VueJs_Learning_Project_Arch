package com.tm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tm.bean.Player;

@Repository
public interface IPlayerRepo extends JpaRepository<Player, Long>{

}
