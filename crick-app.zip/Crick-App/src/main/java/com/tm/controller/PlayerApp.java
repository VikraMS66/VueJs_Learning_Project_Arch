package com.tm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tm.bean.Player;
import com.tm.service.IPlayerService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/cricket/api")
public class PlayerApp {

	@Autowired
	private IPlayerService service;

	// Retrieving all players
	@GetMapping("/players")
	public List<Player> getAllPlays() {
		return service.getAllPlayers();
	}

	// Adding new player
	@PostMapping("/players")
	public Player createPlayer(@RequestBody Player player) {
		return service.addPlayer(player);
	}

	// Fetch player by id
	@GetMapping("/players/{id}")
	public Player getPlayerById(@PathVariable Long id) {
		return service.getPlayerById(id);
	}

	// Updating player details by id
	@PutMapping("/players/{id}")
	public Player updatePlayer(@PathVariable Long id, @RequestBody Player playerDetails) {
		return service.updatePlayer(id, playerDetails);
	}

	// Deleting player by id
	@DeleteMapping("/players/{id}")
	public String deletePlayer(@PathVariable Long id) {
		return service.deletePlayer(id);
	}

}
