<template>
  <h1 class="static-class">Welcome to Vue</h1>
  <h1 :class="textDangerClass">Vue is 3nd most popular javascript framework</h1>
  <h1 :class="textSuccessClass">Vue is 2nd most popular javascript framework</h1>

  <hr />

  <div class="static" :class="{ 'active': isActive, 'text-danger': hasError }">
    We are learning classes and style binding now.
  </div>
  <h1 :class="classObject">Vuejs file have .vue extension</h1>


</template>

<script>

export default {
  name: 'App',
  data() {
    return {
      textDangerClass: 'text-danger',
      textSuccessClass: 'text-success',
      isActive: true,
      hasError: false,
      classObject: {
        'active': false,
        'text-success': true,
      },
    }
  }

}
</script>

<style>
.text-danger {
  color: red;
}

.text-success {
  color: green;
}

.active {
  font-style: italic;
  font-size: large;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
